package org.grails.prettytime

class PrettyTimeException extends RuntimeException {

    PrettyTimeException(String msg) {
        super(msg)
    }

}