class PrettyTimeGrailsPlugin {

    def version = '0.3'
    def dependsOn = [:]

    def author = 'Cazacu Mihai'
    def authorEmail = 'cazacugmihai@yahoo.com'
    def title = 'Pretty-time plugin'
    def description = 'A plugin that allows you to display human readable, relative timestamps.'
    def documentation = 'http://grails.org/PrettyTime+Plugin'

}
